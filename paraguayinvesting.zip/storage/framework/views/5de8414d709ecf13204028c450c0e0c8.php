<!DOCTYPE html>
<html>
<head>
    <title>Nuevo Contacto</title>
</head>
<body>
    <h2>Has recibido una nueva consulta</h2>
    <p><strong>Nombre:</strong> <?php echo e($datos['nombre']); ?></p>
    <p><strong>Email:</strong> <?php echo e($datos['email']); ?></p>
    <p><strong>Mensaje:</strong><br> <?php echo e($datos['mensaje']); ?></p>
</body>
</html>
<?php /**PATH C:\Users\nfueg\OneDrive\Documents\Developer\invierte-landing\resources\views/emails/contacto.blade.php ENDPATH**/ ?>